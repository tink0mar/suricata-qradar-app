from flask import request


def get_date():
    try:
        starttime = request.args.get('starttime')
        endtime = request.args.get('endtime')

        return "START '"  + starttime + "' STOP '" +  endtime + "'"
    except:
        return "LAST 1 DAYS"


def get_log_source():
    return request.args.get('logsource')



def convert_pagination(page, size):
    start = (page - 1) * size
    end = start + size - 1
    return {"Range": "items=" + str(start) + "-" + str(end)}


def get_signature():
    signature = request.args.get('signature')
    if signature is None or len(signature) == 0:
        return ""
    else:
        return "and signature='" + signature + "'"

def get_severity():
    severity = request.args.get('severity')

    if severity is None or len(severity) == 0:
        return ""
    else:
        return "and alert_severity=='" + severity + "'"    


def build_query(eventtype=None):
    if eventtype == "alert":
        return "SELECT  interface, sourceip as \"source IP\", sourceport as \"source port\", destinationip as \"destination IP\", destinationport as \"destination port\", CATEGORYNAME(category) as \"QRadar low category\", QIDNAME(qid) as \"QRadar event name (signature)\", CATEGORYNAME(highLevelCategory) as \"QRadar high category\", PROTOCOLNAME(protocolid) as protocol, signature, severity, DATEFORMAT(startTime, 'yyyy-MM-dd hh:mm:ss') as time"
    elif eventtype == 'http':
        return "SELECT DATEFORMAT(startTime, 'yyyy-MM-dd hh:mm') as time, sourceip, sourceport, destinationip, destinationport, http_user_agent as agent, http_status as status, http_method as method, hostname, http_content_type as content_type, url, PROTOCOLNAME(protocolid) as protocol"
    elif eventtype == 'dns':
        return "SELECT DATEFORMAT(startTime, 'yyyy-MM-dd hh:mm') as time, sourceip, sourceport, destinationip, destinationport, dns_version, flags, qr, aa, tc, rd, ra, rdata "
    elif eventtype == 'tls':
        return "SELECT DATEFORMAT(startTime, 'yyyy-MM-dd hh:mm') as time, sourceip, sourceport, destinationip, destinationport, subject, sni, issuer, tls_serial, fingerprint, tls_version "
    elif eventtype == 'ssh':
        return "SELECT DATEFORMAT(startTime, 'yyyy-MM-dd hh:mm') as time, sourceip, sourceport, destinationip, destinationport, client_software, client_protocol, server_software, server_protocol "
    elif eventtype == 'dhcp':
        return "SELECT DATEFORMAT(startTime, 'yyyy-MM-dd hh:mm') as time, sourceip, sourceport, destinationip, destinationport, message_type, dhcp_type, dhcp_hostname "
    elif eventtype == 'flow':
        return "SELECT DATEFORMAT(startTime, 'yyyy-MM-dd hh:mm') as time, sourceip, sourceport, destinationip, destinationport, bytes_toserver, bytes_toclient, alerted, app_protocol, flow_state as state, pkts_toserver as pakets_toserver, pkts_toclient as pakets_toclient, flow_reason as reason "


def get_order(sort_param, sort_dir):
    if (sort_param is None):
        return 'starttime DESC'
    else:
        return "'" + sort_param + "' "  + sort_dir

