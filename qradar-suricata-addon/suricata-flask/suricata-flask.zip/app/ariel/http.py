from flask import Blueprint, jsonify, request

import helpers
import rest_api

http_db = Blueprint('http', __name__)

@http_db.route('/hostname')
def http_hostname():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT hostname, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'http'  GROUP BY hostname ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@http_db.route('/http-method')
def http_method():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT http_method as method, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'http'  GROUP BY method ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@http_db.route('/http-status')
def http_status():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT http_status as status, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'http'  GROUP BY status ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@http_db.route('/http-user-agent')
def http_user_agent():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT http_user_agent as agent, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'http'  GROUP BY agent ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@http_db.route('/proto')
def http_proto():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT  PROTOCOLNAME(protocolid) as prot, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'http'  GROUP BY prot ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])