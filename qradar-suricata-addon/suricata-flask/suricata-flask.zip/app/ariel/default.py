"""
Blueprint object for routes which returns information about events

"""

from flask import Blueprint, jsonify, request
import rest_api
import helpers

default_db = Blueprint('default', __name__)

log_source_type_name = 'MySuricata'

@default_db.route('/check-connection')
def check_connection():
    api_search = rest_api.API()

    result = api_search.get("/ariel/databases")

    return jsonify(status="ok")


@default_db.route('/log-sources')
def log_sources():
    api_search = rest_api.API()

    result = api_search.get(
        '/config/event_sources/log_source_management/log_sources', params={
            'filter': 'name="MySuricata"',
            'fields': 'name,id'
        })

    return jsonify(log_sources=result[1])


@default_db.route('/categories')
def categories():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT qidname(qid) as category, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source + " and event_type!='alert' GROUP BY category ORDER BY number DESC  LIMIT 6" + time)

    return jsonify(data=result[0]['events'])


@default_db.route('/events-count')
def count():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT COUNT(*) AS event_count FROM events WHERE logsourceid = " + log_source +" " + time)

    return jsonify(data=result[0]['events'])


@default_db.route('/protocols')
def protocols():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT PROTOCOLNAME(protocolid) as prot, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type!='alert' GROUP BY prot " + time)

    return jsonify(data=result[0]['events'])


@default_db.route('/events')
def events():
    api_search = rest_api.Search()

    eventtype = request.args.get('eventtype')
    page = int(request.args.get('page'))
    size = int(request.args.get('size'))

    sort_param = request.args.get('sort[0][field]')
    sort_dir = request.args.get('sort[0][dir]')

    header = helpers.convert_pagination(page, size)

    time = helpers.get_date()
    query = helpers.build_query(eventtype)

    order = helpers.get_order(sort_param, sort_dir)

    log_source = helpers.get_log_source()

    signature_query = helpers.get_signature()
    
    severity = helpers.get_severity()

    events, record_count = api_search.executeSearch(
        query= query + " FROM events WHERE logsourceid = " + log_source +" AND event_type = '" + eventtype + "'" + signature_query + " " + severity + " ORDER BY " + order + " " + time, headers=header)

    last_page = int(record_count)/size + 1
    return jsonify(data=events['events'],last_page=last_page)
