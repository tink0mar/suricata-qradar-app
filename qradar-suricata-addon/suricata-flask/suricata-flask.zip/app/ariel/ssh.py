from flask import Blueprint, jsonify, request

import helpers
import rest_api

ssh_db = Blueprint('ssh', __name__,)


@ssh_db.route('/client-software')
def ssh_client_software():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT client_software, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'ssh' AND client_software IS NOT NULL  GROUP BY client_software ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@ssh_db.route('/client-protocol')
def ssh_client_protocol():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT client_protocol, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'ssh' AND client_protocol IS NOT NULL  GROUP BY client_protocol ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@ssh_db.route('/server-software')
def ssh_server_software():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT server_software, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'ssh' AND server_software IS NOT NULL  GROUP BY server_software ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@ssh_db.route('/server-protocol')
def ssh_server_protocol():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT server_protocol, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'ssh' AND server_protocol IS NOT NULL  GROUP BY server_protocol ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@ssh_db.route('/destip')
def ssh_destip():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT destinationip as ip, COUNT(*)*eventcount as number from events where logsourceid = " + log_source +" and event_type='ssh' GROUP BY ip ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])