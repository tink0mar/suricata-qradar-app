from flask import Blueprint, jsonify, request

import helpers
import rest_api

tls_db = Blueprint('tls', __name__,)


@tls_db.route('/subject')
def tls_subject():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT issuer, COUNT(*)*eventcount as number from events where logsourceid = " + log_source +" and event_type='tls' GROUP BY issuer ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@tls_db.route('/sni')
def tls_sni():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT sni, COUNT(*)*eventcount as number from events where logsourceid = " + log_source +" and event_type='tls' GROUP BY sni ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@tls_db.route('/dest-ip')
def tls_dest_ip():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT destinationip as ip, COUNT(*)*eventcount as number from events where logsourceid = " + log_source +" and event_type='tls' GROUP BY ip ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])
