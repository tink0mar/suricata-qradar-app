const fetchDHCPByType = async () => {
    await fetchMessageChart(
        "dhcp",
        "message-type",
        "chart-dhcp-message-type",
        "Top DHCP messages types"
    )
}

const fetchDHCPByDHCPType = async () => {
    await fetchMessageChart(
        "dhcp",
        "dhcp-type",
        "chart-dhcp-dhcp-type",
        "Top DHCP dhcp types"
    )
}

const fetchDHCPByHostname = async () => {
    await fetchMessageChart(
        "dhcp",
        "hostname",
        "chart-dhcp-hostname",
        "Top DHCP hostnames"
    )
}

const loadDHCPMessageData = async () => {
    try {
        await Promise.all([
            fetchDHCPByType(),
            fetchDHCPByDHCPType(),
            fetchDHCPByHostname(),
        ])
    } catch (e) {
        return e
    }
}
