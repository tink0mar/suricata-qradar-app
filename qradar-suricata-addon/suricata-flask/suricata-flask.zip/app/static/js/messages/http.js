const fetchHTTPByHostname = async () => {
    await fetchMessageChart("http", "hostname", "chart-hostname", "Hostname")
}

const fetchHTTPByHTTPMethod = async () => {
    await fetchMessageChart(
        "http",
        "http-method",
        "chart-http-method",
        "Top HTTP methods"
    )
}

const fetchHTTPByStatus = async () => {
    await fetchMessageChart(
        "http",
        "http-status",
        "chart-http-status",
        "Top HTTP statuses"
    )
}

const fetchHTTPByUserAgent = async () => {
    await fetchMessageChart(
        "http",
        "http-user-agent",
        "chart-http-user-agent",
        "Top user agents"
    )
}

const fetchHTTPByProto = async () => {
    await fetchMessageChart(
        "http",
        "proto",
        "chart-http-proto",
        "Top HTTP transport protocols"
    )
}

const loadHTTPMessageData = async () => {
    try {
        await Promise.all([
            fetchHTTPByHostname(),
            fetchHTTPByHTTPMethod(),
            fetchHTTPByStatus(),
            fetchHTTPByUserAgent(),
            fetchHTTPByProto(),
        ])
    } catch (e) {
        return e
    }
}
