// Fetch select signatures
const fetchSelectSignatures = async () => {
    let signature = $("#select-signatures :selected").val()
    console.log("aaa?", signature, "?", typeof signature, "a")
    $("#select-signatures")
        .children()
        .remove()
        .end()
        .append(
            '<option value="" disabled selected hidden>Choose a signature</option>'
        )

    const signatureDropdown = document.getElementById("select-signatures")

    let option = document.createElement("option")
    let optionText = document.createTextNode("All")
    option.value = ""
    option.appendChild(optionText)
    signatureDropdown.appendChild(option)

    if (signature != "") {
        let option = document.createElement("option")
        let optionText = document.createTextNode(`${signature}`)
        option.value = signature
        option.appendChild(optionText)
        signatureDropdown.appendChild(option)

        $("#select-signatures")[0].selectedIndex = 2
    } else {
        const response = await fetch(
            `data/alert/list-signatures${getTimeQuery()}&logsource=${await getLogSource()}&severity=${getSeverity()}`
        )
        const body = await response.json()
        const signaturesArray = body.data

        for (const item of signaturesArray) {
            let option = document.createElement("option")

            let optionText = document.createTextNode(item.signature)
            option.value = item.signature
            option.appendChild(optionText)
            signatureDropdown.appendChild(option)
        }

        $("#select-signatures")[0].selectedIndex = 1
    }

    $("#select-signatures").niceSelect("update")
}

const fillSelectSeverity = async () => {
    $("#select-severity")
        .children()
        .remove()
        .end()
        .append('<option value="" disabled selected hidden>all</option>')

    const severityDropdown = document.getElementById("select-severity")

    let option = document.createElement("option")
    let optionText = document.createTextNode("All")
    option.value = ""
    option.appendChild(optionText)
    severityDropdown.appendChild(option)

    for (const [index, item] of ["High", "Medium", "Low"].entries()) {
        let option = document.createElement("option")

        let optionText = document.createTextNode(item)
        option.value = index + 1
        option.appendChild(optionText)
        severityDropdown.appendChild(option)
    }

    $("#select-severity").niceSelect("update")
}

const fetchAlertEventsTable = async () => {
    let columns = [
        { title: "time", field: "time" },
        { title: "signature", field: "signature" },
        { title: "QRadar low level", field: "QRadar low category" },
        { title: "QRadar high level", field: "QRadar high category" },
        { title: "severity", field: "severity" },
        { title: "source IP", field: "source IP" },
        { title: "source port", field: "source port" },
        { title: "destination IP", field: "destination IP" },
        { title: "destination port", field: "destination port" },
        { title: "protocol", field: "protocol" },
        { title: "interface", field: "interface" },
    ]

    let table = new Tabulator("#alert-table", {
        columns: columns,
        movableRows: true,
        movableColumns: true,
        pagination: true, //enable.
        paginationMode: "remote", //enable remote pagination
        sortMode: "remote",
        ajaxURL: `data/default/events${getTimeQuery()}&eventtype=alert&logsource=${await getLogSource()}&signature=${getSignature()}&severity=${getSeverity()}`, //set url for ajax request
        paginationSize: 10, //optional parameter to request a certain number of rows per page
        paginationInitialPage: 1, //optional parameter to set the initial page to load
        placeholder: "No data for these dates",
    }).on("rowClick", function (e, row) {
        const dataContainer = document.getElementById("dataContainer")
        dataContainer.innerHTML = generateDataView(row.getData())
        $("#tableModal").modal("show")
    })
}

/**
 * Fetch fata for every minute and count them in the startdate-enddate range
 * 
 * 
 */

const fetchTimeline = async () => {
    const response = await fetch(
        `data/alert/events${getTimeQuery()}&logsource=${await getLogSource()}&severity=${getSeverity()}`
    )
    const body = await response.json()

    document.querySelector(
        `#div-chart-alert-table`
    ).innerHTML = `<div class="alert-line-chart tab-color-border" ><canvas id="chart-alert-table"></canvas></div>`

    let dates = body.data.map((log) => {
        let date = new Date(log.time)
        const timezone = date.getTimezoneOffset() * 60000
        const time = new Date(date.getTime() + timezone)
        time.setSeconds(0)
        time.setMilliseconds(0)
        return time.getTime()
    })

    const dateArray = []

    for (
        let date = new Date(getStartTime());
        date <= new Date(getEndTime());
        date.setMinutes(date.getMinutes() + 1)
    ) {
        const formatedDateKey = formateDate(date)
        dateArray[date.getTime()] = []
    }

    dates.map((date) => {
        dateArray[date].push(date)
    })

    let data = []
    const dateArraylen = Object.entries(dateArray).length

    // go trough the object for 
    Object.entries(dateArray).forEach(([key, value], i) => {
        const count = value.length

        if (count != 0 || (dateArraylen > 0 && i % 6 != 0)) {
            data.push({
                x: parseInt(key),
                y: count,
            })
        } else {
            data.push({
                x: parseInt(key),
                y: count,
            })
        }
    })

    const chart = new Chart(document.getElementById("chart-alert-table"), {
        type: "line",
        data: {
            datasets: [
                {
                    label: "Alerts per minute",
                    data: data,
                    borderColor: "#003049",
                    borderWidth: 2,
                    pointBackgroundColor: "#003049",
                    pointRadius: 0,
                    fill: true,
                },
            ],
        },
        options: {
            plugins: {
                title: {
                    display: true,
                    text: "Alerts over time",
                    color: "#003049",
                    font: {
                        size: 18,
                        weight: 600,
                        family: "'Poppins', sans-serif",
                    },
                },
            },
            parsing: false,
            animation: false,
            responsive: true,
            interaction: {
                mode: "nearest",
                axis: "x",
                intersect: false,
            },
            scales: {
                x: {
                    type: "time",
                    time: {
                        unit: "minute",
                        displayFormats: {
                            hour: "MM-dd HH:mm",
                        },
                    },
                    min: new Date(getStartTime()).getTime(),
                    max: new Date(getEndTime()).getTime(),
                    title: {
                        display: true,
                        text: "Time",
                        font: {
                            size: 18,
                            weight: 600,
                            family: "'Poppins', sans-serif",
                        },
                        color: "#003049",
                    },
                    ticks: {
                        callback: function (val, index) {
                            const dateObj = moment(
                                this.getLabelForValue(val),
                                "MMM D, YYYY, h:mm:ss a"
                            )
                            const formattedDate = dateObj.format("DD-MM HH:mm")

                            return index % 4 == 0 ? formattedDate : ""
                        },
                    },
                },
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: "Number of alerts",
                        color: "#003049",
                        font: {
                            size: 18,
                            weight: 600,
                            family: "'Poppins', sans-serif",
                        },
                    },
                    font: {
                        size: 18,
                    },
                },
            },
        },
    })
}

const loadAlertsTop = async () => {
    const response = await fetch(
        `data/alert/top?starttime=${getStartTime()}&endtime=${getEndTime()}&type={{type}}&logsource=${await getLogSource()}`
    )
    const body = await response.json()

    const highAlertCount =
        body.alert_high.length === 0 ? 0 : body.alert_high[0].event_count

    document.querySelector(
        "#number-of-hig-alerts"
    ).textContent = `${highAlertCount}`

    const mediumAlertCount =
        body.alert_medium.length === 0 ? 0 : body.alert_medium[0].event_count

    document.querySelector(
        "#number-of-medium-alerts"
    ).textContent = `${mediumAlertCount}`

    const lowAlertCount =
        body.alert_low.length === 0 ? 0 : body.alert_low[0].event_count

    document.querySelector(
        "#number-of-low-alerts"
    ).textContent = `${lowAlertCount}`

    const topSignature =
        body.top_signature.length === 0 ? 0 : body.top_signature[0].signature

    document.querySelector("#top-signature").textContent = `${topSignature}`
}

const fetchAlertByCategories = async () => {
    await fetchMessageChart(
        "alert",
        "categories",
        "chart-alert-categories",
        "Top alert rules categories"
    )
}

const fetchAlertBySignatures = async () => {
    await fetchMessageChart(
        "alert",
        "signatures",
        "chart-alert-signatures",
        "Top alert signatures"
    )
}

const fetchAlertByAppProto = async () => {
    await fetchMessageChart(
        "alert",
        "app-proto",
        "chart-alert-app-proto",
        "Top alerts transport protocols"
    )
}

const fetchAlertByProto = async () => {
    await fetchMessageChart(
        "alert",
        "proto",
        "chart-alert-proto",
        "Top alert application protocols"
    )
}

const fetchAlertBySourceProto = async () => {
    await fetchMessageChart(
        "alert",
        "source-port",
        "chart-alert-source-port",
        "Top alert source ports"
    )
}

const fetchAlertBySourceIP = async () => {
    await fetchMessageChart(
        "alert",
        "source-ip",
        "chart-alert-source-ip",
        "Top alert source IPs"
    )
}

const fetchAlertByDestProto = async () => {
    await fetchMessageChart(
        "alert",
        "dest-port",
        "chart-alert-dest-port",
        "Top alert destination ports"
    )
}

const fetchAlertByLowCategories = async () => {
    await fetchMessageChart(
        "alert",
        "low-categories",
        "chart-alert-low-categories",
        "Top alert low categories"
    )
}

const fetchAlertByHighCategories = async () => {
    await fetchMessageChart(
        "alert",
        "high-categories",
        "chart-alert-high-categories",
        "Top alert high categories"
    )
}

const fetchAlertByOffenses = async () => {
    await fetchMessageChart(
        "alert",
        "offenses",
        "chart-alert-offenses",
        "Alerts with offenses"
    )
}

const fetchAlertByInterfaces = async () => {
    await fetchMessageChart(
        "alert",
        "interfaces",
        "chart-alert-interfaces",
        "Top alert interfaces"
    )
}

const fetchAlertByDestIP = async () => {
    await fetchMessageChart(
        "alert",
        "dest-ip",
        "chart-alert-dest-ip",
        "Top alert destination IPs"
    )
}

const loadAlertsData = async (type) => {
    try {
        await Promise.all([
            fetchAlertByCategories(),
            fetchAlertBySignatures(),
            fetchAlertByProto(),
            fetchAlertBySourceProto(),
            fetchAlertBySourceIP(),
            fetchAlertByDestProto(),
            fetchAlertByAppProto(),
            fetchAlertByDestIP(),
            fetchAlertByInterfaces(),
            fetchAlertByLowCategories(),
            fetchAlertByHighCategories(),
            fetchAlertByOffenses(),
            loadAlertsTop(),
            fetchAlertEventsTable(),
            fetchTimeline(),
        ])
        await fetchSelectSignatures()
    } catch (e) {
        throw e
    }
}
