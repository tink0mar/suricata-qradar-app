const getTopOffenseSourceIp = (offenses) => {
    return offenses.reduce((acc, curr) => {
        let exists = false

        for (var i = 0; i < acc.length; i++) {
            if (acc[i].ip === curr.offense_source) {
                acc[i].number += curr.event_count
                exists = true
            }
        }

        if (!exists) {
            acc.push({
                ip: curr.offense_source,
                number: 1 * curr.event_count,
            })
        }

        return acc
    }, [])
}

const createOffenseChart = (offenses) => {
    const data = getTopOffenseSourceIp(offenses)

    const chartId = "chart-offense-count"

    document.querySelector(
        `#div-${chartId}`
    ).innerHTML = ` <div class="tooltip" id=tooltip-${chartId}> 
                        <span class="name" id="text-${chartId}">Matko</span>
                        <div class="tooltip-wrap"> 
                            <div class="box" id="box-${chartId}"></div>
                            <span id="value-${chartId}"></span>            
                        </div>
                    </div>

                    <div class="border-tab tab-color-border">
                        <canvas id="${chartId}"></canvas>
                    </div>`

    new Chart(chartId, {
        type: "doughnut",
        data: {
            labels: data.map((item) => {
                return item.ip
            }),
            datasets: [
                {
                    backgroundColor: interpolateColors(offenses.length),
                    data: data.map((item) => item.number),
                },
            ],
        },
        options: {
            borderWidth: 1,
            aspectRatio: 2,
            plugins: {
                legend: {
                    position: "left",
                    labels: {
                        boxWidth: 8,
                        boxHeight: 10,
                        padding: 2,
                        font: {
                            size: 14,
                            family: "'Poppins', sans-serif",
                        },
                    },
                    onHover: function (event, legendItem, legend) {
                        event.native.target.style.cursor = "pointer"
                        const item = data[legendItem.index]

                        $(`#text-${chartId}`).text(legendItem.text)
                        $(`#value-${chartId}`).text(item.number)
                        $(`#box-${chartId}`).css(
                            "background-color",
                            legendItem.fillStyle
                        )
                        $(`#tooltip-${chartId}`).css("top", `${event.y + 30}px`)
                        $(`#tooltip-${chartId}`).css("left", `${event.x / 2}px`)
                        $(`#tooltip-${chartId}`).css("visibility", "visible")
                        $(`#tooltip-${chartId}`).css("opacity", "1")
                    },
                    onLeave: function (event, legendItem, legend) {
                        $(`#tooltip-${chartId}`).css("opacity", "0")
                        $(`#tooltip-${chartId}`).css("visibility", "hidden")
                    },
                },
                title: {
                    display: true,
                    text: "Top offense source IPs",
                    font: {
                        size: 18,
                        weight: 600,
                        family: "'Poppins', sans-serif",
                    },
                    color: "#003049",
                },
                tooltip: {
                    displayColors: true,
                    backgroundColor: "#000000",
                    bodyFontColor: "#FFFFFF",
                    bodyFontSize: 12,
                    boxWidth: 10,
                },
            },
        },
    })
}

const fetchOffenseTable = async (offenses) => {
    if (offenses != undefined) {
        for (let i; i < offenses.length; i++) {
            offenses[i].date = formateDate(new Date(offense.date))
        }
    }

    var table = new Tabulator("#offense-table", {
        autoColumns: true,
        movableRows: true,
        data: offenses,
        movableColumns: true,
        pagination: true,
        paginationSize: 15,
        paginationInitialPage: 1,
        placeholder: "No data for these dates",
    }).on("rowClick", function (e, row) {
        const dataContainer = document.getElementById("dataContainer")
        dataContainer.innerHTML = generateDataView(row.getData())
        $("#tableModal").modal("show")
    })
}

const loadOffenseCharts = async () => {
    epochStartTime = new Date(getStartTime()).getTime()
    epochEndTime = new Date(getEndTime()).getTime()

    const response = await fetch(
        `data/alert/offense?logsource=${await getLogSource()}&epochstarttime=${epochStartTime}&epochendtime=${epochEndTime}`
    )
    const body = await response.json()

    const data = body.data

    document.querySelector("#number-of-offenses").textContent = `${data.length}`
    createOffenseChart(data)

    fetchOffenseTable(data)
}

const loadOffenseData = async (type) => {
    try {
        await getLogSource()

        await Promise.all([loadOffenseCharts(), fetchOffenseTable()])
    } catch (e) {
        throw e
    }
}
