const generateDataView = (data) => {
    let html = ""
    for (const key in data) {
        html += `
                <div class="row">
                    <div class="name col-6">
                        ${key}
                    </div>
                    <div class="data col-6">
                        ${data[key]}
                    </div>
                </div>
            `
    }

    return html
}

const formateDate = (date) => {
    return (
        date.getFullYear() +
        "-" +
        ("0" + (date.getMonth() + 1)).slice(-2) +
        "-" +
        ("0" + date.getDate()).slice(-2) +
        " " +
        ("0" + date.getHours()).slice(-2) +
        ":" +
        ("0" + date.getMinutes()).slice(-2)
    )
}

const getStartTime = () => {
    const startDate =
        document.querySelector("#starttime")._flatpickr.selectedDates[0]
    return formateDate(startDate)
}

const getEndTime = () => {
    const endDate =
        document.querySelector("#endtime")._flatpickr.selectedDates[0]
    return formateDate(endDate)
}

const getTimeQuery = () => {
    return `?starttime=${getStartTime()}&endtime=${getEndTime()}`
}

const getLogSource = async () => {
    return new Promise((resolve, reject) => {
        const logSourceId = $("#select-log-source :selected").val()

        if (logSourceId === "") {
            $("#warning-modal-subtitle").text("Log source not selected!")
            $("#warning-modal").modal("show")
            reject(Error("log-source-not-selected"))
        } else {
            resolve(logSourceId)
        }
    })
}

const checkTime = async () => {
    const startTime = getStartTime()
    const endTime = getEndTime()

    if (new Date(startTime) > new Date(endTime)) {
        $("#warning-modal-subtitle").text(
            "The start time must not be after the end time!"
        )
        $("#warning-modal").modal("show")
        throw Error("start-time-after-end-time")
    }
}

const truncateString = (str, maxLength) => {
    if (typeof str === "number") {
        return str
    } else if (str.length <= maxLength) {
        return str
    }

    return str.substr(0, maxLength - 2) + ".."
}

const splitLongString = (str, maxLength) => {
    if (str.length > maxLength) {
        return str.slice(0, maxLength) + "\n" + str.slice(maxLength)
    }
    return str.toString()
}

function calculatePoint(i, intervalSize, colorRangeInfo) {
    var { colorStart, colorEnd, useEndAsStart } = colorRangeInfo
    return useEndAsStart
        ? colorEnd - i * intervalSize
        : colorStart + i * intervalSize
}

/* Must use an interpolated color scale, which has a range of [0, 1] */
function interpolateColors(dataLength) {
    const colorRangeInfo = {
        colorStart: 0,
        colorEnd: 1,
        useEndAsStart: false,
    }

    var { colorStart, colorEnd } = colorRangeInfo
    var colorRange = colorEnd - colorStart
    var intervalSize = colorRange / dataLength
    var i, colorPoint
    var colorArray = []

    for (i = 0; i < dataLength; i++) {
        colorPoint = calculatePoint(i, intervalSize, colorRangeInfo)
        colorArray.push(
            d3.piecewise(d3.interpolateRgb.gamma(2.2), [
                "#fcbf49",

                "#f77f00",

                "#003049",
            ])(colorPoint)
        )
    }

    return colorArray
}

const getSignature = () => {
    return $("#select-signatures :selected").val()
}

const getSeverity = () => {
    return $("#select-severity :selected").val()
}

const fetchMessageChart = async (
    subdomain,
    endpoint,
    chartId,
    title,
    bigSize = false
) => {
    const response = await fetch(
        `data/${subdomain}/${endpoint}${getTimeQuery()}&logsource=${await getLogSource()}&severity=${getSeverity()}&signature=${getSignature()}`
    )

    const body = await response.json()

    const data = body.data

    const properties = [
        "port",
        "ip",
        "prot",
        "hostname",
        "method",
        "status",
        "agent",
        "rrtype",
        "dnstype",
        "rrname",
        "client_software",
        "client_protocol",
        "server_software",
        "server_protocol",
        "subject",
        "sni",
        "type",
        "signature",
        "category",
        "hasOffense",
        "high_category",
        "low_category",
        "interface",
    ]

    document.querySelector(`#div-${chartId}`).innerHTML = ` 
                    <div class="tooltip" id=tooltip-${chartId}> 
                        <span class="name" id="text-${chartId}">Matko</span>
                        <div class="tooltip-wrap"> 
                            <div class="box" id="box-${chartId}"></div>
                            <span id="value-${chartId}"></span>            
                        </div>
                    </div>
                    
                    <div class="border-tab tab-color-border">
                        <canvas id="${chartId}"></canvas>
                    </div>`

    new Chart(chartId, {
        type: "doughnut",
        data: {
            labels: data.map((item) => {
                const labelProp = properties.find((prop) => item[prop] != null)
                const labeName = labelProp ? item[labelProp] : "Unknown"
                return truncateString(labeName.toString(), 20)
            }),
            datasets: [
                {
                    backgroundColor: interpolateColors(data.length),
                    data: data.map((item) => item.number),
                },
            ],
        },
        options: {
            maintainAspectRatio: bigSize ? false : true,
            borderWidth: 1,
            aspectRatio: 2,
            responsive: true,
            plugins: {
                legend: {
                    position: bigSize ? "top" : "left",
                    labels: {
                        boxWidth: 8,
                        boxHeight: 10,
                        padding: bigSize ? 16 : 2,
                        font: {
                            size: bigSize ? 16 : 14,
                            family: "'Poppins', sans-serif",
                        },
                    },
                    onHover: function (event, legendItem, legend) {
                        event.native.target.style.cursor = "pointer"
                        console.log(legendItem)

                        const item = data[legendItem.index]
                        const labelProp = properties.find(
                            (prop) => item[prop] != null
                        )
                        const labelName = labelProp
                            ? item[labelProp]
                            : "Unknown"

                        $(`#text-${chartId}`).text(labelName)
                        $(`#value-${chartId}`).text(item.number)
                        $(`#box-${chartId}`).css(
                            "background-color",
                            legendItem.fillStyle
                        )
                        $(`#tooltip-${chartId}`).css("top", `${event.y + 30}px`)
                        $(`#tooltip-${chartId}`).css("left", `${event.x / 2}px`)
                        $(`#tooltip-${chartId}`).css("visibility", "visible")
                        $(`#tooltip-${chartId}`).css("opacity", "1")
                    },
                    onLeave: function (event, legendItem, legend) {
                        $(`#tooltip-${chartId}`).css("opacity", "0")
                        $(`#tooltip-${chartId}`).css("visibility", "hidden")
                    },
                },
                title: {
                    display: true,
                    text: title,
                    font: {
                        size: 18,
                        weight: 600,
                        family: "'Poppins', sans-serif",
                    },
                    color: "#003049",
                },
                tooltip: {
                    displayColors: true,
                    backgroundColor: "#000000",
                    bodyFontColor: "#FFFFFF",
                    bodyFontSize: 12,
                    boxWidth: 10,
                    borderWidth: 0,
                    callbacks: {
                        title: (context) => {
                            const item =
                                data[
                                    context[0].chart.tooltip.dataPoints[0]
                                        .dataIndex
                                ]
                            const labelProp = properties.find(
                                (prop) => item[prop] != null
                            )
                            const labelName = labelProp
                                ? item[labelProp]
                                : "Unknown"

                            return truncateString(labelName.toString(), 57)
                        },
                    },
                },
            },
        },
    })
}

const fetchLogSourceSelect = async () => {
    return new Promise(async (resolve, reject) => {
        const response = await fetch("data/default/log-sources")
        const body = await response.json()
        const logSourcesDropdown = document.getElementById("select-log-source")

        const logSourcesArray = body.log_sources

        if (logSourcesArray.length === 0) {
            $("#warning-modal-subtitle").text("No Suricata log source avaible!")
            $("#warning-modal").modal("show")

            reject("no-log-source-avaible")
        }

        for (const item of logSourcesArray) {
            let option = document.createElement("option")

            let optionText = document.createTextNode(item.name)
            option.value = item.id
            option.appendChild(optionText)
            logSourcesDropdown.appendChild(option)
        }

        $("#select-log-source")[0].selectedIndex = 1
        $("#select-log-source").niceSelect("update")
        resolve()
    })
}

const checkConnection = async () => {
    const connectionStatusDot = document.querySelector(
        ".div-connection-status .status-dot"
    )

    const response = await fetch(`data/default/check-connection`)

    if (response?.ok) {
        connectionStatusDot.classList.add("connected")
        connectionStatusDot.classList.remove("disconnected")
        connectionStatusDot.textContent = "ON"
    } else {
        connectionStatusDot.classList.add("disconnected")
        connectionStatusDot.classList.remove("connected")
        connectionStatusDot.textContent = "OFF"
        $("#warning-modal-subtitle").text("QRadar Ariel not connected")
        $("#warning-modal").modal("show")
        throw Error("not-connected")
    }
}
