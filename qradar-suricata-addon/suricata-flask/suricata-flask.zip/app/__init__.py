
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from ariel.alerts import alerts_db
from ariel.default import default_db
from ariel.dhcp import dhcp_db
from ariel.dns import dns_db
from ariel.flow import flow_db
from ariel.http import http_db
from ariel.ssh import ssh_db
from ariel.tls import tls_db

__author__ = 'IBM'

from flask import Flask, render_template, request, redirect, url_for
import os

app = Flask(__name__)

@app.route("/")
@app.route("/index")
def alerts():
    return render_template("alerts.html", title="alerts")


@app.route("/messages")
def messages():
    message_type = request.args.get('type')
    return render_template("messages.html", type=message_type, title="messages")


@app.route('/debug')
def debug():
    return 'Pong!'

# APP factory
app.register_blueprint(alerts_db, url_prefix='/data/alert')
app.register_blueprint(default_db, url_prefix='/data/default')
app.register_blueprint(dhcp_db, url_prefix='/data/dhcp')
app.register_blueprint(dns_db, url_prefix='/data/dns')
app.register_blueprint(flow_db, url_prefix='/data/flows')
app.register_blueprint(http_db, url_prefix='/data/http')
app.register_blueprint(ssh_db, url_prefix='/data/ssh')
app.register_blueprint(tls_db, url_prefix='/data/tls')

if __name__ == '__main__':
    app.run()