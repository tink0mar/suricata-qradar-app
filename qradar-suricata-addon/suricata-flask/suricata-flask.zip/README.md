# Python flas development

run this application in development mode and set up credentials in rest_api.py file
