"""
Blueprint object for routes which returns information about dhcp

"""

from flask import Blueprint, jsonify, request

import helpers
import rest_api

dhcp_db = Blueprint('dhcp', __name__,)


@dhcp_db.route('message-type')
def dhcp_message_type():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT message_type as type, COUNT(*)*eventcount as number from events where logsourceid = " + log_source +" and event_type='dhcp' GROUP BY type ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@dhcp_db.route('dhcp-type')
def dhcp_type():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT dhcp_type as type, COUNT(*)*eventcount as number from events where logsourceid = " + log_source +" and event_type='dhcp' GROUP BY type ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@dhcp_db.route('hostname')
def dhcp_hostname():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT dhcp_hostname as hostname, COUNT(*)*eventcount as number from events where logsourceid = " + log_source +" and event_type='dhcp' GROUP BY hostname ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])
