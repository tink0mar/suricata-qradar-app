"""
Blueprint object for routes which returns information about events

"""

from flask import Blueprint, jsonify, request

import helpers
import rest_api

alerts_db = Blueprint('alerts', __name__)

# route for retrieve events
@alerts_db.route('/events')
def alerts_events():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query=" SELECT starttime  as time FROM events WHERE logsourceid = " + log_source +" AND event_type = 'alert'  " + signature_query + " " + severity +" ORDER BY time ASC " + time)

    return jsonify(data=result[0]['events'])

# route for retrieve top information about different severities
@alerts_db.route('/top')
def alert_top():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    alert_high = api_search.executeSearch(
        query="SELECT COUNT(*)*eventcount AS event_count FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "and alert_severity==1 " + time)

    alert_medium = api_search.executeSearch(
        query="SELECT COUNT(*)*eventcount AS event_count FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "and alert_severity==2 " + time)

    alert_low = api_search.executeSearch(
        query="SELECT COUNT(*)*eventcount AS event_count FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "and alert_severity==3 " + time)

    top_signature = api_search.executeSearch(
        query="SELECT signature as signature, COUNT(*)*eventcount AS number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "ORDER BY number DESC LIMIT 1 " + time)

    return jsonify(alert_high=alert_high[0]['events'],
            alert_medium=alert_medium[0]['events'],
            alert_low= alert_low[0]['events'],
            top_signature=top_signature[0]['events'])

# route for retrieve information about alert categories
@alerts_db.route('/categories')
def alerts_categories():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()
        
    result = api_search.executeSearch(
        query=" SELECT alert_category as category, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY category  ORDER BY number DESC  LIMIT 5  " + time)
    return jsonify(data=result[0]['events'])

# route for retrieve information about signatures
@alerts_db.route('/signatures')
def alerts_signatures():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query=" SELECT signature , COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY signature  ORDER BY number DESC  LIMIT 5  " + time)

    return jsonify(data=result[0]['events'])

# route for application protocols
@alerts_db.route('/app-proto')
def alerts_app_proto():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query="SELECT PROTOCOLNAME(protocolid) as prot, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY prot  ORDER BY number DESC  LIMIT 5  " + time)

    return jsonify(data=result[0]['events'])


# route for retrieve information about transport protocols
@alerts_db.route('/proto')
def alerts_proto():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query=" SELECT app_protocol as prot, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY prot  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])

# route for retrieve information about source protocols
@alerts_db.route('/source-port')
def alerts_source_port():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query="SELECT sourceport as port, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY port  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])

# route for retrieve information about source ips
@alerts_db.route('/source-ip')
def alerts_source_ip():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query="SELECT sourceip as ip, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY ip  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])

# route for retrieve information about destination ips
@alerts_db.route('/dest-ip')
def alert_dest_ip():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query=" SELECT destinationip as ip, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY ip  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])

# route for retrieve information about destination ports
@alerts_db.route('/dest-port')
def alerts_dest_port():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query=" SELECT destinationport as port, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY port  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])

# route for retrieve information about used interfaces
@alerts_db.route('/interfaces')
def alerts_interfaces():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query=" SELECT interface, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY interface  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])

# route for retrieve information about low categories
@alerts_db.route('/low-categories')
def alerts_low_categories():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query=" SELECT CATEGORYNAME(category) as low_category, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY category  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])

# route for retrieve information about high categories
@alerts_db.route('/high-categories')
def alerts_high_categories():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query=" SELECT CATEGORYNAME(highLevelCategory) as high_category , COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY highLevelCategory  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])

# route for retrieve information about offenses
@alerts_db.route('/offenses')
def alerts_offense():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query=" SELECT hasOffense, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY hasOffense  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])

# route for retrieve list of signatures
@alerts_db.route('/list-signatures')
def alerts_list_signatures():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query=" SELECT signature FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity + "GROUP BY signature  " + time)
    return jsonify(data=result[0]['events'])

# route for retrieve about signatures
@alerts_db.route('/signature')
def alert_signature():
    api_search = rest_api.Search()
    time = helpers.get_date()

    log_source = helpers.get_log_source()
    signature = helpers.get_signature()

    big_query = "SELECT  interface, sourceip, sourceport, destinationip, destinationport, CATEGORYNAME(category) as \"qradar low category\", QIDNAME(qid) as \"qradar event name(signature)\", CATEGORYNAME(highLevelCategory) as \"qradar high category\", PROTOCOLNAME(protocolid) as protocol, signature, severity, DATEFORMAT(startTime, 'yyyy-MM-dd hh:mm:ss') as time"

    severity = helpers.get_severity()

    signature_query = helpers.get_signature()

    result = api_search.executeSearch(
        query= big_query + " FROM events WHERE logsourceid = " + log_source +" and event_type='alert' " + signature_query + " " + severity +"" + signature + "GROUP BY signature" + time)
    return jsonify(data=result[0]['events'])


# offenses
# route for retrieve about every active offense

@alerts_db.route('/offense')
def alerts_get_offense():
    api_search = rest_api.API()

    epoch_start_time = request.args.get('epochstarttime')
    epoch_end_time = request.args.get('epochendtime')

    log_source = helpers.get_log_source()

    filter_for_offense = "log_sources contains id=" + log_source + " and start_time > " + epoch_start_time +  "and start_time <" + epoch_end_time 

    result = api_search.get('/siem/offenses', params={
        "filter": filter_for_offense,
        "fields": "id, start_time, description, offense_source, event_count, magnitude, severity, categories",
    })

    return jsonify(data=result[1])
