"""
Blueprint object for routes which returns information about flows

"""

from flask import Blueprint, jsonify, request

import helpers
import rest_api

flow_db = Blueprint('flow', __name__)

@flow_db.route('/source-ip')
def flows_source_ip():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT sourceip as ip, SUM(bytes_toserver + bytes_toclient) AS number FROM events WHERE logsourceid = " + log_source +" and event_type='flow' GROUP BY ip  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@flow_db.route('/dest-ip')
def flows_dest_ip():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT destinationip as ip, SUM(bytes_toserver + bytes_toclient) AS number FROM events WHERE logsourceid = " + log_source +" and event_type='flow' GROUP BY ip  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@flow_db.route('/source-port')
def flows_source_port():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT sourceport as port, SUM(bytes_toserver + bytes_toclient) AS number FROM events WHERE logsourceid = " + log_source +" and event_type='flow' GROUP BY port  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@flow_db.route('/dest-port')
def flows_dest_port():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT destinationport as port, SUM(bytes_toserver + bytes_toclient) AS number FROM events WHERE logsourceid = " + log_source +" and event_type='flow' GROUP BY port  ORDER BY number DESC  LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@flow_db.route('/protocols')
def flows_protocols():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT app_protocol as prot, SUM(bytes_toserver + bytes_toclient) AS number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'flow' AND app_protocol != 'failed' AND app_protocol IS NOT NULL  GROUP BY prot LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@flow_db.route('/alerted')
def flows_alerted():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT alerted , COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'flow' AND alerted = 'true' GROUP BY alerted " + time)
    return jsonify(data=result[0]['events'])