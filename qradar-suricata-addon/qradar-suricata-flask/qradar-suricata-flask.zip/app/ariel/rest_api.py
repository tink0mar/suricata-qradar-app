"""
Classes for fetching data from QRadar Api

"""


import json
import requests
from flask import jsonify

from qpylib import qpylib

class API:
    def __init__(self, base_url='/api', headers=None):
        self.base_url = base_url
        self.headers = {}
        # for development version
        #self.headers = {"SEC": "c69be11d-a40d-4f40-99ea-a934e55f0da4"}
        #self.URL = "https://127.0.0.1:4430"
        #self.URL = "https://192.168.100.8"

    def _parseResponse(self, response):

        status_code = response.status_code
        body_dict = json.loads(response.content)
        
        return status_code, body_dict

    def get(self, endpoint, headers={}, params=None):
        url = self.base_url + endpoint

        merged_headers = self.headers.copy()
        if headers is not None:
            merged_headers.update(headers)
        response = qpylib.REST(
            "GET", url, headers=merged_headers, params=params, verify=False)

        # for development version
        #response = requests.get(self.URL + self.base_url + endpoint, params=params,
        #                    headers=merged_headers, verify=False)
        
        return self._parseResponse(response)

    def post(self, endpoint, data=None, params=None):
        url = self.base_url + endpoint

        response = qpylib.REST(
            "POST", url, headers=self.headers, params=params, verify=False, )

        # for development version
        #response = requests.post(self.URL  + self.base_url + endpoint, params=params,
        #                     headers=self.headers, verify=False, data=data)
        
        return self._parseResponse(response)


class Search(API):

    search_id = None
    endpoint = '/ariel/searches'
    select = None
    record_count = None

    def executeSearch(self, query, headers=None):
        self.select = query

        self.createSearch(query)
        self.checkSearch()

        result = self.getResult(headers)

        return result, self.record_count

    def createSearch(self, query):
        params = {
            "query_expression": query
        }

        status_code, body = self.post(
            self.endpoint, data=None, params=params)
        print(body['status'])
        self.search_id = body['search_id']

        return status_code, body

    def checkSearch(self):

        endpoint = self.endpoint + '/' + self.search_id

        status_code, body = self.get(endpoint=endpoint)
        self.record_count = body['record_count']

        if body['completed'] == True:
            return True
        else:
            self.checkSearch()

    def getResult(self, headers={}):

        endpoint = self.endpoint + '/' + self.search_id + '/results'

        status_code, body = self.get(endpoint=endpoint, headers=headers)

        return body
