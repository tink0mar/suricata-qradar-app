"""
Blueprint object for routes which returns information about dns

"""

from flask import Blueprint, jsonify

import helpers
import rest_api

dns_db = Blueprint('dns', __name__)


@dns_db.route('/rrtype')
def dns_rrtype():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT rrtype, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'dns'  GROUP BY rrtype ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@dns_db.route('/type')
def dns_type():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT type as dnstype, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'dns'  GROUP BY type ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])


@dns_db.route('/rrname')
def dns_rrname():
    api_search = rest_api.Search()

    time = helpers.get_date()

    log_source = helpers.get_log_source()

    result = api_search.executeSearch(
        query="SELECT rrname, COUNT(*)*eventcount as number FROM events WHERE logsourceid = " + log_source +" AND event_type = 'dns'  GROUP BY rrname ORDER BY number DESC LIMIT 5 " + time)

    return jsonify(data=result[0]['events'])
