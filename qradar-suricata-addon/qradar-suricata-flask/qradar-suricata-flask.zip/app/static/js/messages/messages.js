/**
 * Functions for generating graphs and tables in message card
 */

const fetchEventsCount = async () => {
    const response = await fetch(
        `data/default/events-count?starttime=${getStartTime()}&endtime=${getEndTime()}&type={{type}}&logsource=${await getLogSource()}`
    )
    const body = await response.json()
    const data = body.data

    const eventCount = data.length === 0 ? 0 : data[0].event_count
    document.querySelector(".numberOfEvents").textContent = `${eventCount}`
}

const fetchCategories = async () => {
    await fetchMessageChart(
        "default",
        "categories",
        "chart-types",
        "Top QRadar Identifiers"
    )
}

const fetchProtocols = async () => {
    await fetchMessageChart(
        "default",
        "protocols",
        "chart-proto",
        "Top transport protocols"
    )
}

const fetchEvents = async (type) => {
    let table = new Tabulator("#message-table", {
        autoColumns: true,
        pagination: true, //enable.
        paginationMode: "remote", //enable remote pagination
        ajaxURL: `data/default/events${getTimeQuery()}&eventtype=${type}&logsource=${await getLogSource()}`, //set url for ajax request
        paginationSize: 10, //optional parameter to request a certain number of rows per page
        paginationInitialPage: 1, //optional parameter to set the initial page to load
        placeholder: "No data for these dates",
    }).on("rowClick", function (e, row) {
        const dataContainer = document.getElementById("dataContainer")
        dataContainer.innerHTML = generateDataView(row.getData())
        $("#exampleModalLabel").text(`HTTP`)
        $("#tableModal").modal("show")
    })
}

const loadMessageData = async (type) => {
    try {
        await Promise.all([
            fetchCategories(),
            fetchProtocols(),
            fetchEventsCount(),
            fetchEvents(type),
        ])
    } catch (e) {
        throw e
    }
}
