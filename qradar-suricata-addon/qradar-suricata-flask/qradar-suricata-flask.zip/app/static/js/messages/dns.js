const fetchDNSByRrtype = async () => {
    await fetchMessageChart(
        "dns",
        "rrtype",
        "chart-dns-rrtype",
        "Top DNS rrtypes"
    )
}

const fetchDNSByType = async () => {
    await fetchMessageChart("dns", "type", "chart-dns-type", "Top DNS types")
}

const fetchDNSByRrname = async () => {
    await fetchMessageChart(
        "dns",
        "rrname",
        "chart-dns-rrname",
        "Top DNS rrnames"
    )
}

const loadDNSMessageData = async () => {
    try {
        await Promise.all([
            fetchDNSByRrtype(),
            fetchDNSByType(),
            fetchDNSByRrname(),
        ])
    } catch (e) {
        return e
    }
}
