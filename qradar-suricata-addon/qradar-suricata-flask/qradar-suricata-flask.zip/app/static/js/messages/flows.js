/* FLOWS */

const fetchFlowsBySourceIp = async () => {
    await fetchMessageChart(
        "flows",
        "source-ip",
        "chart-source-ip",
        "Top source IP bytes"
    )
}

const fetchFlowsByDestIp = async () => {
    await fetchMessageChart(
        "flows",
        "dest-ip",
        "chart-dest-ip",
        "Top destination IP bytes"
    )
}

const fetchFlowsBySourcePort = async () => {
    await fetchMessageChart(
        "flows",
        "source-port",
        "chart-source-port",
        "Top source port bytes"
    )
}

const fetchFlowsByDestPort = async () => {
    await fetchMessageChart(
        "flows",
        "dest-port",
        "chart-dest-port",
        "Top destination port bytes"
    )
}

const fetchFlowsByProtocols = async () => {
    await fetchMessageChart(
        "flows",
        "protocols",
        "chart-prot",
        "Top protocols bytes"
    )
}

const fetchAlerted = async () => {
    const response = await fetch(
        `data/flows/alerted?starttime=${getStartTime()}&endtime=${getEndTime()}&logsource=${await getLogSource()}`
    )
    const body = await response.json()
    const data = body.data

    const alerted = data.length === 0 ? 0 : data[0].number
    console.log(alerted, "kokot")
    document.querySelector("#numberOfAlerted").textContent = `${alerted}`
}

const loadFlowsMessageData = async () => {
    try {
        await Promise.all([
            fetchFlowsBySourceIp(),
            fetchFlowsByDestIp(),
            fetchFlowsBySourcePort(),
            fetchFlowsByDestPort(),
            fetchFlowsByProtocols(),
            fetchAlerted(),
        ])
    } catch (e) {
        throw e
    }
}
