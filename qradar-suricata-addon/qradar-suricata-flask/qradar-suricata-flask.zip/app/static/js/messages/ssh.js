const fetchSSHByClientSoft = async () => {
    await fetchMessageChart(
        "ssh",
        "client-software",
        "chart-ssh-client-software",
        "Top SSH client softwares"
    )
}

const fetchSSHByClientProt = async () => {
    await fetchMessageChart(
        "ssh",
        "client-protocol",
        "chart-ssh-client-protocol",
        "Top SSH client protocols"
    )
}

const fetchSSHServerSoft = async () => {
    await fetchMessageChart(
        "ssh",
        "server-software",
        "chart-ssh-server-software",
        "Top SSH server softwares"
    )
}

const fetchSSHServerProt = async () => {
    await fetchMessageChart(
        "ssh",
        "server-protocol",
        "chart-ssh-server-protocol",
        "Top server protocols"
    )
}

const fetchDNSByDestip = async () => {
    await fetchMessageChart(
        "ssh",
        "destip",
        "chart-ssh-destip",
        "Top SSH dest ip"
    )
}

const loadSSHMessageData = async () => {
    try {
        await Promise.all([
            fetchSSHByClientSoft(),
            fetchSSHByClientProt(),
            fetchSSHServerSoft(),
            fetchSSHServerProt(),
            fetchDNSByDestip(),
        ])
    } catch (e) {
        return e
    }
}
