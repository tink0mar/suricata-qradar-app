const fetchTLSBySubject = async () => {
    await fetchMessageChart(
        "tls",
        "subject",
        "chart-tls-subject",
        "Top TLS subjects"
    )
}

const fetchTLSBySni = async () => {
    await fetchMessageChart("tls", "sni", "chart-tls-sni", "Top TLS sni")
}

const fetchTLSByDestIp = async () => {
    await fetchMessageChart(
        "tls",
        "dest-ip",
        "chart-tls-dest-ip",
        "Top TLS destination IPs"
    )
}

const loadTLSMessageData = async () => {
    try {
        await Promise.all([
            fetchTLSBySubject(),
            fetchTLSBySni(),
            fetchTLSByDestIp(),
        ])
    } catch (e) {
        return e
    }
}
